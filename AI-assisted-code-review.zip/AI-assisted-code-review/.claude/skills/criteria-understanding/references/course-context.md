# Course Context

## Educational Goals (course-stated)

- The course emphasizes learning through project work.
- Students are expected to develop independence in finding and using appropriate learning resources.
- Peer assessment is a learning activity. Its purpose is to help students:
  - learn by examining other students' solutions
  - develop their ability to give constructive feedback
  - develop technical understanding by examining other projects
  - reflect on different ways of solving problems

## AI Support Principles

The following are the operating rules for AI assistance on criteria understanding in this course. They are a separate governing framework, not part of the course's own pedagogical statement above.

AI should support the student's learning process rather than replace it.

For criteria understanding, AI may:
- explain assessment criteria
- clarify terminology
- explain relevant concepts
- tell students what kinds of evidence to look for
- provide generic examples
- suggest relevant learning concepts or resources

AI should not:
- perform the peer assessment for the student
- independently identify issues in another group's work
- decide whether the peer project satisfies the criterion

The student should examine the project and make the initial judgment.
