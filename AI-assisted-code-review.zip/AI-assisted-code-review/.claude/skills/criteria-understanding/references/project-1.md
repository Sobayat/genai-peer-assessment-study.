# Project 1

## Description

A group submission (link to the project's git repo, with a link to the deployed website included in the project's documentation). After the group submission, individual peer assessment follows: each student is assigned 2 peer projects to give feedback on, and can then review and comment on any feedback their own group receives. Repos are made public for the duration of the peer-assessment period.

## Relevant Requirements

To apply the rubric, a reviewer should understand that the project involves: HTML, CSS, and TypeScript; React (state, props, hooks, and file/component organization); a REST API; the Web Storage API (localStorage/sessionStorage); git-based development (issues, commits); testing (including snapshots, component tests, and mocking of API calls); and project documentation.

## Rubric

### Funksjonelle krav

**Utforming og interaksjon**
Gi konstruktive tilbakemelding på hvordan gruppa her løst kravene som er listet for hvordan ressurser skal presenteres og interageres med.

**Responsivt design**
Gi tilbakemelding på hvordan gruppa her løst kravet om responsivt design.

**Utforming og stiling**
Gi konstruktive tilbakemeldinger på den generelle utformingen av applikasjonen.

### Tekniske løsninger

**HTML, CSS, Typescript**
Gi konstruktive tilbakemeldinger på bruk av HTML, CSS og Typescriptkoden.

**React**
Gi konstruktive tilbakemeldinger på bruken av React: bruk av state, props, hooks, hvordan komponentene er organisert i filer etc.

**REST API**
Gi konstruktive tilbakemeldinger på bruk av REST API og hvordan dette er løst. Bruk gjerne utviklerverktøyet i en nettleser til å undersøke hvordan applikasjonen oppfører seg.

**Web storage API**
Gi konstruktive tilbakemeldinger på bruk av localstorage eller sessionstorage i applikasjonen. Brukes det hensiktsmessig og effektivt, er det andre anvendelser de kunne tenkt på.

### Utvikling, testing og dokumentasjon

**Bruk av git**
Gi konstruktive tilbakemeldinger på bruk av git mtp issues og commits. Viser dette en god utviklingsprosess?

**Testing**
Gi konstruktive tilbakemeldinger på testing. Viser de bruk av snapshots, har de med gode eksempler på komponenttesting, er det bruk av mocking for å unngå faktisk REST API kall når testene kjøres. Har de testet applikasjonen manuelt for responsivt design, og samsvarer gruppas testing med din utprøving?

**Dokumentasjon**
Gi konstruktive tilbakemeldinger på dokumentasjonen. Er den lesbar, oversiktlig, relevant og forståelig?

### Oppsummert

**Generell vurdering av løsninger**
Hvilke score vil du gi for løsningen? Valget "vesentlige mangler" (laveste score) bruker du når det er helt essensielle og lett påviselige feil. "Perfekt" (høyeste score) bruker du hvis du mener dette er et eksemplarisk godt prosjekt som det er lagt vesentlig arbeid i å perfeksjonere. Score du gir vil ikke ha konsekvens for vurderingen som gjøres av fagstab.

**Læringsutbytte**
Hvilken score vil du gi for oppnådd læringsutbytte (dvs hvor godt løsningen viser kunnskap og ferdigheter)? Valget "Vesentlige mangler" bruker du når det er åpenbart behov for å sette seg bedre inn i vesentlige elementer. Valget "Fremragende" bruker du hvis du mener dette viser fremragende kunnskaper og ferdigheter på alle områder.
