# Project 2-1 (first interim submission)

## Description

The first interim submission for Project 2. It should only be a draft of the system, using mockup data or hardcoded static data. The goal is to get started, show off the group's own idea, and get feedback — as well as see what other groups have planned. There are no strict requirements beyond peers being able to understand what the group intends to do.

## Relevant Requirements

The submission is expected to sketch a data choice, and optionally a database/backend choice, and an initial application design. The wider project requires solutions that scale (work independent of data volume), so the data choice should be considered with that in mind.

## Rubric

### Valg av data
Gi konstruktive tilbakemeldinger til hvilken datasamling gruppen har tenkt å jobbe med. Er dette data som gir godt grunnlag for å jobbe med funksjonalitet i frontend, som er greie å sette opp en database og backend for. I prosjektet skal det jobbe med løsninger som vil skalere (fungere uavhengig av mengden data). Har gruppa valgt data som gir et godt grunnlag for å tenke skalerbarhet?

### Valg av database og backend-løsning
Hvis gruppen beskriver valg på database og backend, kan du gi konstruktive tilbakemeldinger her. Hvis gruppen ikke har gjort valg, kan du gi tips og råd her.

### Utforming av applikasjonen
Gi konstruktive tilbakemeldinger på det gruppen skisserer av utforming og funksjonalitet. Kom gjerne med tips og råd her også.
