# Project 2-2 (second interim submission)

## Description

The second interim submission for Project 2. The group should have a running database and backend on a VM, and the client should support some interaction. The focus is on working client–backend interplay, and correct setup, installation, and running of the backend. The goal is to get feedback, have the setup tested by others, and see/read how others have set theirs up — active participation in the interim submissions and peer review is what counts.

## Relevant Requirements

A running database, a backend deployed and running on a VM, a client with at least some interactivity, and documentation of how to set up and run the project.

## Rubric

### Oppsett
Sett deg inn i hvordan prosjektet et satt opp. Hvilken database som er brukt, hvordan er backend-skriptet implementert, dokumenterer de oppsett og kjøring på en god og forståelig måte?. Sjekk om det er installert en klient og test ut det som eventuelt finnes av funksjonalitet.

Gi konstruktive tilbakemeldinger på valg av løsninger og gi tilbakemeldinger på hva du har lært av å se på dette prosjektet.
