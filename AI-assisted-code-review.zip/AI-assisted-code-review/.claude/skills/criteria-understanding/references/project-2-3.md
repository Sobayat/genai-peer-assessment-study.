# Project 2-3 (beta / first full prototype)

## Description

This interim submission should be the first full prototype (beta version), providing a good basis for trying out and quality-checking functional features such as search, paging, sorting, and filtering. This submission is also where sustainable-development and accessibility requirements are reviewed, and where feedback on code quality is requested.

## Relevant Requirements

Working search, paging, sorting, and filtering; consideration of sustainable-development choices (e.g. data transfer, images, video, fonts, colors); accessibility requirements; flexible layout (responsive design is not an explicit P2 requirement but is implicit in the accessibility requirements); React implementation choices (state, caching, third-party libraries/components); folder/component organization and naming (code quality); optional use of generative AI.

## Rubric

### Applikasjonsforståelse

**Funksjonalitet**
Diskuter valg og løsninger som er gjort mtp de interaktive elementene. Sammenlign gjerne med hva du vanligvis finner og forventer av profesjonelle applikasjoner.

Trekk frem elementer du synes er spesielt bra løst, eller elementer som tydelig har et forbedringspotensiale. Er det en skalerbar løsning, hvordan blir brukeropplevelsen etc. Indiker gjerne om dere synes de har gått for trivielle løsninger kontra litt mer utfordrende.

**Design og utforming**
Diskuter/kommenter visuelle og estetiske aspekter, plassering av elementer i forhold til hverandre, bruk av farger og bildet, fonter, marger etc. Sjekk også at løsningen ikke feiler på fleksibel layout. Vi har ikke noe eksplisitt krav om responsiv design i P2, men det er implisitt en del av tilgjengelighetskravene.

### Teknisk egenskaper

**Tekniske valg**
Diskuter tekniske løsninger og implementasjon, valg av tredjeparts bibliotek/komponenter, bruk av løsninger for state, caching, React-programmeringen etc. Viser de god forståelse og mener du det er gode valg?

**Kodekvalitet**
Gi din vurdering av kodekvalitet, eksempelvis organisering av prosjektet i mapper, navngiving, bruk og gjenbruk av komponenter, ryddighet etc. Let gjerne opp prinsipper for clean code eller best practise for kode og mappestruktur for React-prosjekter.

**Bærekraft**
Har gruppen forklart og valgt gode og effektive løsninger hvor det er tenkt bærekraft eks i overføring av data, bruk av bilder, video, fonter, farger etc.

**Tilgjengelighet**
Diskuter hvordan applikasjonen løser krav til tilgjengelighet. Her kan du godt teste applikasjonen eks. med Google Lighthouse, sjekke koden for semantisk html, teste applikasjonen med en skjermleser, prøve å navigere kun med tastatur etc.

**Bruk av kunstig intelligens**
Har gruppen brukt generativ KI i prosjektet? og er dette godt dokumentert og forklart? Er det elementer i prosjektet hvor de med fordel kunne brukt KI til å forbedre eller jobbe mer effektivt?
