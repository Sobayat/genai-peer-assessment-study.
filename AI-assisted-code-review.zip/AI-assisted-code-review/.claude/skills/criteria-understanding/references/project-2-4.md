# Project 2-4 (near-final submission)

## Description

This interim submission should be a (practically) finished, working solution. The peer assessment for this submission focuses on giving a final round of feedback, with particular attention to testing.

## Relevant Requirements

A near-complete, working application; React component tests; end-to-end (E2E) tests covering key user scenarios; optional API/backend testing (e.g. GraphQL); and test documentation/organization.

## Rubric

### Funksjonalitet, design og utforming

**Funksjonalitet**
Prøv ut applikasjonens funksjonalitet manuelt og gi tilbakemeldinger på feil du oppdager, interaksjon som kan forbedres etc.

**Design og utforming**
Gi tilbakemeldinger på hvordan du opplever design og utforming av applikasjonen.

### Testing

**Komponenttesting**
Vurder kvaliteten og omfanget av React-komponenttester

Er det skrevet tester for sentrale komponenter?

Testes både rendering, brukerinteraksjon og state-håndtering?

Er testene meningsfulle og dekker de både normale og edge-cases?

Brukes test-biblioteker på en god måte?

**Ende-til-ende testing (E2E)**
Vurder implementering av automatiserte brukerinteraksjon-tester.

Er typiske brukerscenarier dekket som en sammenhengende testsekvens (eks søk → resultat → detaljer → filtrering)?

Testes kritisk funksjonalitet som søk, paginering og brukerdata-lagring?

Er E2E-testene stabile og kjører de konsistent (eller opplever du feil eller kræsj når testene kjører)?

**API/Backend-testing (ikke obligatorisk)**
Vurder testing av GraphQL-endepunkter og backend-logikk.

Vi har noe krav om spesifikke backendtester, men greit å reflektere om det er gjort og evt. hvordan. Er GraphQL queries og mutations testet enten eksplisitt eller implisitt?

Testes feilhåndtering og edge-cases i backend?

**Testdekning og edge-cases**
Vurder hvor grundig applikasjonen er testet.

Dekkes både "happy path" (dvs, interaksjoner som lykkes) og feilscenarier?

Testes applikasjonen med store datamengder (skalerbarhet)?

Håndteres tomme resultater, nettverksfeil og ugyldig input?

Er tilgjengelighetsfunksjoner testet (tabbing etc)?

**Testkvalitet og dokumentasjon**
Vurder struktur, lesbarhet og vedlikeholdbarhet av testene

Er testene godt organisert og lette å forstå?

Brukes beskrivende test-navn som forklarer hva som testes?

Er det klare instruksjoner for å kjøre testene?
